<?php

if(isset($_GET['id'])){

	require_once 'ProduitManager.php';

	$p = ProduitManager::findOneById($_GET['id']);

	if($p != false){

		$p_ = $p[0];

		if(isset($_POST['modifier'])){

			if(!isset($_POST['nom_produit']) || empty($_POST['nom_produit'])){


				echo 'Veuillez renseigner un nom de produit';
			}

			if(!isset($_POST['categorie']) || empty($_POST['categorie'])){

				echo 'Veuillez renseigner une catégorie de produit';
			}

			else{

				// Je ne vérifie pas la description car elle est autorisée à être vide en base
	
				// Mise à jour de l'objet
				$p->setNom($_POST['nom_produit'])
					->setDescription($_POST['description'])
					->setCategorieId($_POST['categorie']);
				// Sauvegarde
				$pm = new ProduitManager();

				if($pm->update($p) > 0){


					header('Location: http://localhost:8080/crud_php/');


				}

				else{
					echo "<p>Une erreur est survenue</p>";
				}
			}

		}else{

			?>



			  <!-- Modal AJOUTER ARTICLES-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="    margin-top: 100px; margin-right: 380px;margin-left: 380px;margin-bottom: 100px;
    padding: 20px;
    border-style: groove;
    border-radius: 10px;">
        <div class="modal-header">
                
          <h4 class="modal-title" style="color: #f73b00;
    text-align: center;
    font-weight: bold;
    font-size: 25px;">MODIFIER UN ARTICLE</h4>
        </div>  
        <div class="modal-body">
         
<form  action="update_produit.php?id=<?= $_GET['id'] ?>" method="POST" class="form-inline">

  <div class="row">
    <div style="margin-left:10Opx;" class="col">
      <input style="float: right; height: 35px;  width: 180px;
    margin-right: 140px;" name="nom_produit" id="nom_produit" type="text" class="form-control" placeholder="Nom produit" value="<?= $p_->getNom(); ?>">
    </div>  
    
    <div class="form-group col" style="margin-left: 130px;">

    <select class="custom-select mr-sm-2" name="categorie" id="categorie" aria-label="Default select example" style="
    height: 35px;
    color: green;
    font-weight: bold;
    border-color: #9e9e9e8c;
    border-radius: 4px;
">    
                   <option  value="<?= $p_->getCategorieId(); ?>" selected>Choisir Catégorie ici</option>

                   <?php
			require_once 'CategorieManager.php';
			$categories = CategorieManager::findAll();
			        foreach ($categories as $c) {

					?>

				        <option value="<?=$c->id_categorie; ?>"><?= $c->nom_categorie; ?></option>

					<?php
				}
			?>
        </select>




    </div>

    <div style="text-align: center;
    margin-top: 13px;">
        <textarea style="width: 350px;
    margin-right: 10px;
    height: 100px;" class="form-control" id="description" name="description" placeholder="Commentaire" ><?= $p_->getDescription(); ?></textarea>
    
    </div>
      

  </div>


  <br>

<div style="text-align: center; ">


                <button type="submit" style="padding: 8px;
    background-color: red;
    color: white;
    border-radius: 10px;
    border-block-color: black;
	border-block-color: black;
    cursor: pointer;" name="modifier" class="btn btn-primary mb-2">VALIDER LA MODIFICATION</button>

</div>
</form>

        </div>
        
      </div>
      
    </div>
  </div>
			
		<?php
		}
	}
	else{
		echo "<p>Produit introuvable</p>";
	}
}
else{
	echo "<p>Produit introuvable</p>";
}
