<?php

class Produit{
	
	private $id_produit;
	private $nom_produit;
	private $commentaire_produit;
	private $categorie_id;
	
	public function getId() : int
	{
		return $this->id_produit;
	}

	public function setNom(string $n) : self
	{
		$this->nom_produit = $n;
		return $this;
	}
	public function getNom() : string
	{
		return $this->nom_produit;
	}

	public function setDescription(?string $d) : self
	{
		$this->commentaire_produit = $d;
		return $this;
	}
	public function getDescription() : ?string
	{
		return $this->commentaire_produit;
	}

	public function setCategorieId(int $id) : self
	{
		$this->categorie_id = $id;
		return $this;
	}
	public function getCategorieId() : int
	{
		return $this->categorie_id;
	}
}