<?php

require_once 'database.php';
require_once 'Categorie.php';

class CategorieManager extends Categorie{
	
	public static function findAll(){
		$sql = 'SELECT * FROM categorie';

		$bdd = new Database();
		$co = $bdd->connect();	
		$req = $co->prepare($sql);
		$req->execute();

		return $req->fetchAll(PDO::FETCH_OBJ);
	}

	public static function findOneById(int $id){

		$sql = 'SELECT * FROM categorie WHERE id_categorie = :id';

		$bdd = new Database();
		$co = $bdd->connect();
		$req = $co->prepare($sql);
		$req->execute([
			'id' => $id
		]);

		return $req->fetchAll(PDO::FETCH_CLASS, 'Categorie');

	}

}