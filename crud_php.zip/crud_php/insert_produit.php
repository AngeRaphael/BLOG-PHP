<?php

require_once 'ProduitManager.php';

if(!isset($_POST['nom_produit']) || empty($_POST['nom_produit'])){
	echo 'Veuillez renseigner un nom de produit';
}
if(!isset($_POST['categorie']) || empty($_POST['categorie'])){
	echo 'Veuillez renseigner une catégorie de produit';
}
else{
	// Je ne vérifie pas la description car elle est autorisée à être vide en base

	// Création de l'objet
	$p = new ProduitManager();
	$p->setNom($_POST['nom_produit'])
		->setDescription($_POST['description'])
		->setCategorieId($_POST['categorie']);
        
	// Sauvegarde
	if($p->save() > 0){
		

		header('Location: http://localhost:8080/crud_php/');

	}
	else{
		echo "<p>Une erreur est survenue</p>";
	}
}
