<?php

class Categorie{
	private $id_categorie;
	private $nom_categorie;
	private $commentaire_categories;
	
	public function getId() : int
	{
		return $this->id_categorie;
	}

	public function setNom(string $n) : self
	{
		$this->nom_categorie = $n;
		return $this;
	}
	public function getNom() : string
	{
		return $this->nom_categorie;
	}

	public function setDescription(?string $d) : self
	{
		$this->commentaire_categories = $d;
		return $this;
	}
	public function getDescription() : ?string
	{
		return $this->commentaire_categories;
	}
}