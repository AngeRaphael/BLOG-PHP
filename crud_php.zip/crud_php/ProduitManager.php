<?php

require_once 'database.php';
require_once 'Produit.php';

class ProduitManager extends Produit{

	public static function findAll(){

		$sql = 'SELECT * FROM produits ORDER BY id_produit DESC';

		$bdd = new Database();
		$co = $bdd->connect();
		$req = $co->prepare($sql);
		$req->execute();

		return $req->fetchAll(PDO::FETCH_OBJ);

	}


	public function save(){

		$sql = 'INSERT INTO produits(nom_produit, commentaire_produit, categorie_id) VALUES (:n, :d, :c)';

		$bdd = new Database();
		$co = $bdd->connect();
		$req = $co->prepare($sql);

		$req->execute([

			'n' => $this->getNom(),
			'd' => $this->getDescription(),
			'c' => $this->getCategorieId()

		]);

		return $req->rowCount();
	}

	public static function findOneById(int $id){

		$sql = 'SELECT * FROM produits WHERE id_produit = :id';

		$bdd = new Database();
		$co = $bdd->connect();
		$req = $co->prepare($sql);

		$req->execute([

			'id' => $id
		]);

		return $req->fetchAll(PDO::FETCH_CLASS, 'Produit');
	}

	public function update(Produit $p){
		
		$sql = 'UPDATE produits SET nom_produit = :n, commentaire_produit = :d, categorie_id = :c WHERE id_produit = :id';

		$bdd = new Database();
		$co = $bdd->connect();
		$req = $co->prepare($sql);
		$req->execute([
			'n' => $p->getNom(),
			'd' => $p->getDescription(),
			'c' => $p->getCategorieId(),
			'id'=> $p->getId()
		]);

		return $req->rowCount();
	}


	public static function delete(int $id){
		$sql = 'DELETE FROM produits WHERE id_produit = :id';
		$bdd = new Database();
		$co = $bdd->connect();
		$req = $co->prepare($sql);
		$req->execute([
			'id' => $id
		]);

		return $req->rowCount();
	}
}