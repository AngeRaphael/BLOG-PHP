


<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BLOG EN POO</title>

        	<link href="css/bootstrap.min.css" rel="stylesheet">
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    </head>

    <style>

            th{
                    text-align: center;
            }

        .titre {
                text-shadow: 3px 2px #000;
                text-align: center;
                color: white;
                width: auto;
                font-weight: bolder;
                font-size: 30px;
        }


        </style>

    <body>

    <br />
        <div class="container">

            <br />
            <div class="row">

                <br />
                <nav class="navbar navbar-dark bg-dark">
                       
                <div class="container-fluid titre">

                        <span >BIENVENUE SUR LE BLOG 2A</span>

                        </div>
                </nav>
                <p>

            </div>

            <p>

            <br />

            <div class="row">
                

                <?php

                require_once 'ProduitManager.php';

                $produits = ProduitManager::findAll();

                if(count($produits) > 0){

                ?>


      

        <div style="text-align: right;">
                <button style="width: 140px;  padding:10px;    height: 37px; margin:auto;    background-color: #ff9800; border-color: #ffffff;" class="btn btn-success". data-toggle="modal" data-target="#myModal" >  AJOUTER ARTICLE</button>

        </div>

        <div style="text-align: left; z-index: 1; ">
        <select class="" name="categorie_2" id="categorie_2" aria-label="Default select example" style="
        height: 35px;
        color: green;
        font-weight: bold;
        border-color: #9e9e9e8c;
        border-radius: 4px;

        margin-bottom:50px;

        width:20%;
        margin-top:80px;">   <option selected>Tous Les Articles Par Catégories</option>

<?php
			require_once 'CategorieManager.php';
			$categories = CategorieManager::findAll();
			        foreach ($categories as $c) {

					?>

				        <option value="<?=$c->id_categorie; ?>"><?=$c->id_categorie; ?> - <?= $c->nom_categorie; ?></option>

					<?php
				}
			?>
        </select>



        </div>
       

 <span style="margin-top: -120px; " class="table-responsive">


                <table class="table table-hover table-bordered">

            <br />

            <thead style="background-color: green; color:white; border-color:black">

            <th>Noms Articles </th>
            <p>


            <th>Commentaire Articles</th>
            <p>


            <th>Categories Articles</th>
            <p>


            <th>Edition</th>
            <p>


            </thead>

            <p>

           <br />


                <?php
                        foreach ($produits as $p) {
                        

                                ?>

                <tbody>

                
        
                        <br />
                        <tr>

                

                        <td><?= $p->nom_produit; ?></td>
                        <p>



                        <td><?= $p->commentaire_produit; ?></td>
                        <p>
                     

                        
                        <td><?= $p->categorie_id ?> </td> 

                        <p>
                        
                      
                <p>

     
                
                <td>


                <div style="text-align: center;">


                        <a class="btn btn-danger" href="delete_produit.php?id=<?= $p->id_produit; ?>">Supprimer</a>

                        <a class="btn btn-warning" href="update_produit.php?id=<?= $p->id_produit; ?>" >Modifier</a>                     


                        </div>

               
                </td>
                        <p>

                        
                                                
                </tr>
                        <p>
                                
                                                
                        <?php

                        };
                ?>

                        </tbody>

                </table>

                <?php
                }
           else{
        // Je ne possède pas de produits
        echo "<p>Il n'y a aucun produit</p>";
        }
    ?>
    
    <p>

    </table>
    <p>

</span>


    <p>


    </div>
    <p>


    </div>
    <p>


    <!-- Modal AJOUTER ARTICLES-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
                
          <h4 class="modal-title" style="color: green;">AJOUTER UN ARTICLE</h4>
        </div>  
        <div class="modal-body">
         
<form action="insert_produit.php" method="POST" class="form-inline">

  <div class="row">
    <div style="margin-left:10Opx;" class="col">
      <input style="float: right;" name="nom_produit" id="nom_produit" type="text" class="form-control" placeholder="Nom produit">
    </div>  
    
    <div class="form-group col">

    <select class="custom-select mr-sm-2" name="categorie" id="categorie" aria-label="Default select example" style="
    height: 35px;
    color: green;
    font-weight: bold;
    border-color: #9e9e9e8c;
    border-radius: 4px;
">    
                   <option selected>Choisir Catégorie ici</option>

                   <?php
			require_once 'CategorieManager.php';
			$categories = CategorieManager::findAll();
			        foreach ($categories as $c) {

					?>

				        <option value="<?=$c->id_categorie; ?>"><?= $c->nom_categorie; ?></option>

					<?php
				}
			?>
        </select>




    </div>

    <div style="text-align: center;
    margin-top: 13px;">
        <textarea style="width: 350px; margin-right: 10px;" class="form-control" id="description" name="description" placeholder="Commentaire" ></textarea>
    
    </div>
      

  </div>


  <br>

<div style="text-align: center; ">


                <button type="submit" name="ajouter" class="btn btn-primary mb-2">VALIDER</button>

</div>
</form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Annulée</button>
        </div>
      </div>
      
    </div>
  </div>




   
    </body>



</html>
