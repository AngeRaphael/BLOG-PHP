<?php

if(isset($_GET['id'])){

	require_once 'ProduitManager.php';

	$p = ProduitManager::delete($_GET['id']);

	if($p > 0){


		header('Location: http://localhost:8080/crud_php/');

	}

	else{
		echo "<p>Produit introuvable</p>";
	}
}
else{
	echo "<p>Produit introuvable</p>";
}
