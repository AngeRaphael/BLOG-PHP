<?php

require_once 'database.php';

$bdd = new Database();
$co = $bdd->connect();

$req = $co->prepare('INSERT INTO categorie(nom_categorie, commentaire_categories) VALUES (:n, :d)');

$req->execute([
	'n' => 'Catégorie',
	'd' => 'Commentaire de la catégorie'
]);