<?php

if(isset($_GET['id'])){

	require_once 'ProduitManager.php';

	$p = ProduitManager::findOneById($_GET['id']);

	if($p != false){

		$p_ = $p[0];

		if(isset($_POST['modifier'])){

			if(!isset($_POST['nom_produit']) || empty($_POST['nom_produit'])){


				echo 'Veuillez renseigner un nom de produit';
			}

			if(!isset($_POST['categorie']) || empty($_POST['categorie'])){

				echo 'Veuillez renseigner une catégorie de produit';
			}

			else{


                echo 'Les mises à jour on été prise en compte';

				// Je ne vérifie pas la description car elle est autorisée à être vide en base
	
				// Mise à jour de l'objet
				$p_->setNom($_POST['nom_produit'])
					->setDescription($_POST['description'])
					->setCategorieId($_POST['categorie']);
				// Sauvegarde
				$pm = new ProduitManager();

				if($pm->update($p_) > 0){


					header('Location: http://localhost:8080/crud_php/index.php');


				}

				else{
					echo "<p>Une erreur est survenue</p>";
				}
			}

		}else{

			?>

			
		<?php
		}
	}
	else{
		echo "<p>Produit introuvable</p>";
	}
}
else{
	echo "<p>Produit introuvable</p>";
}
